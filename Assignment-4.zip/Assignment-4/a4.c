/*
    Name : JEEVITHA AB
    Date : 22-04-2023
    Description : A4 - WAP to understand advanced file control system calls
*/

#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>

void prime(int size)
{
    int i, j;
    int prime[size];

    for(i=0; i<size; i++)
    {
        prime[i] = i;
    }
    for(i=2; i<size; i++)
    {
        for(j=2; i*j<=size; j++)
        {
            prime[i*j] = 0;
        }
    }
    printf("Prime less than or equal to %d are : ", size);
    for(i=2; i<size; i++)
    {
        if(prime[i])
        {
            // print all non zero element prime numbers
            printf("%d ", i);
        }
    }
    printf("\n");
}

int main(int argc, char *argv[])
{
    if(argc == 2)
    {
        // open file in write only mode
        int fd = open(argv[1], O_WRONLY);
        
        if(fd == -1)
        {
            perror("open");
            return -1;
        }
        
        // declare structure variable
        struct flock lock;
        // assign to zero to all structure member
        memset(&lock, 0, sizeof(lock));

        lock.l_type = F_WRLCK;
        
        fcntl(fd, F_SETLKW, &lock);

        // create child
        int pid = fork();
        
        if(pid == 0)
        {
            // lock the file
            // fcntl(fd, F_SETLKW, &lock);
            
            printf("CHILD PROCESS: locked file\n");
            printf("CHILD PROCESS: writing to file %s\n", argv[1]);

            // backup stdout(1)
            dup2(1,15);
            // copy fd to 1
            dup2(fd,1);

            // initializing the variables
            int num = 15, t1 = 0, t2 = 1, nextterm = 0;

            //logic for fibonacci's series
            printf("Fibonacci series : ");
            printf("%d %d ", t1, t2);
            
            nextterm = t1 + t2;

            while(nextterm <= num)
            {
                printf("%d ", nextterm);

                // swap the previous values
                t1 = t2;
                t2 = nextterm;
                nextterm = t1 + t2;
            }
            printf("\n");

            // again stdout copy to 1
            dup2(15,1);
            // unlock the file
            fcntl(fd, F_UNLCK, &lock);

            printf("CHILD PROCESS : unlocked file\n");
        }
        else
        {
            // lock the file
            fcntl(fd, F_SETLKW, &lock);

            printf("PARENT PROCESS : locked file\n");
            printf("PARENT PROCESS : writing to file %s\n", argv[1]);

            dup2(1, 5);
            dup2(fd,1);

            // call function for print prime numbers
            prime(15);

            // unlock the file
            fcntl(fd, F_UNLCK, &lock);
            
            dup2(5,1);
            printf("PARENT PROCESS : unlocked file\n");
        }
        close(fd);
    }
    else
    {
        printf("Insufficient arguments \nUsage : ./a.out <filename> \n");
    }
    return 0;
}
